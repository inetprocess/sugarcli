-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: May 12, 2017 at 04:06 PM
-- Server version: 5.5.54-0+deb7u2
-- PHP Version: 5.4.45-0+deb7u8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sugarcli_sugar`
--

-- --------------------------------------------------------

--
-- Table structure for table `sugarcli_test_accounts`
--

CREATE TABLE IF NOT EXISTS `sugarcli_test_accounts` (
  `id` char(36) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `team_id` char(36) DEFAULT NULL,
  `team_set_id` char(36) DEFAULT NULL,
  `facebook` varchar(100) DEFAULT NULL,
  `twitter` varchar(100) DEFAULT NULL,
  `googleplus` varchar(100) DEFAULT NULL,
  `account_type` varchar(50) DEFAULT NULL,
  `industry` varchar(50) DEFAULT NULL,
  `annual_revenue` varchar(100) DEFAULT NULL,
  `phone_fax` varchar(100) DEFAULT NULL,
  `billing_address_street` varchar(150) DEFAULT NULL,
  `billing_address_city` varchar(100) DEFAULT NULL,
  `billing_address_state` varchar(100) DEFAULT NULL,
  `billing_address_postalcode` varchar(20) DEFAULT NULL,
  `billing_address_country` varchar(255) DEFAULT NULL,
  `rating` varchar(100) DEFAULT NULL,
  `phone_office` varchar(100) DEFAULT NULL,
  `phone_alternate` varchar(100) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `ownership` varchar(100) DEFAULT NULL,
  `employees` varchar(10) DEFAULT NULL,
  `ticker_symbol` varchar(10) DEFAULT NULL,
  `shipping_address_street` varchar(150) DEFAULT NULL,
  `shipping_address_city` varchar(100) DEFAULT NULL,
  `shipping_address_state` varchar(100) DEFAULT NULL,
  `shipping_address_postalcode` varchar(20) DEFAULT NULL,
  `shipping_address_country` varchar(255) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `sic_code` varchar(10) DEFAULT NULL,
  `duns_num` varchar(15) DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sugarcli_test_accounts`
--

INSERT INTO `sugarcli_test_accounts` (`id`, `name`, `date_entered`, `date_modified`, `modified_user_id`, `created_by`, `description`, `deleted`, `assigned_user_id`, `team_id`, `team_set_id`, `facebook`, `twitter`, `googleplus`, `account_type`, `industry`, `annual_revenue`, `phone_fax`, `billing_address_street`, `billing_address_city`, `billing_address_state`, `billing_address_postalcode`, `billing_address_country`, `rating`, `phone_office`, `phone_alternate`, `website`, `ownership`, `employees`, `ticker_symbol`, `shipping_address_street`, `shipping_address_city`, `shipping_address_state`, `shipping_address_postalcode`, `shipping_address_country`, `parent_id`, `sic_code`, `duns_num`, `campaign_id`) VALUES('14c0b225-ea9d-f063-7cef-57d02c797f5f', 'White Cross Co', '2016-09-07 15:03:20', '2016-09-07 15:03:20', '1', '1', NULL, 0, 'seed_sally_id', 'West', '718eecb2-5273-8be2-968a-57d02cdee75f', NULL, NULL, NULL, 'Customer', 'Education', NULL, NULL, '999 Baker Way', 'Alabama', 'CA', '83203', 'USA', NULL, '(971) 971-6510', NULL, 'www.imim.cn', NULL, NULL, NULL, '999 Baker Way', 'Alabama', 'CA', '83203', 'USA', NULL, NULL, NULL, NULL);
INSERT INTO `sugarcli_test_accounts` (`id`, `name`, `date_entered`, `date_modified`, `modified_user_id`, `created_by`, `description`, `deleted`, `assigned_user_id`, `team_id`, `team_set_id`, `facebook`, `twitter`, `googleplus`, `account_type`, `industry`, `annual_revenue`, `phone_fax`, `billing_address_street`, `billing_address_city`, `billing_address_state`, `billing_address_postalcode`, `billing_address_country`, `rating`, `phone_office`, `phone_alternate`, `website`, `ownership`, `employees`, `ticker_symbol`, `shipping_address_street`, `shipping_address_city`, `shipping_address_state`, `shipping_address_postalcode`, `shipping_address_country`, `parent_id`, `sic_code`, `duns_num`, `campaign_id`) VALUES('1787b708-d842-9b40-3d8d-57d02c19b79f', 'Q.R.&E. Corp', '2016-09-07 15:03:20', '2016-09-07 15:03:20', '1', '1', NULL, 0, 'seed_sally_id', 'West', 'West', NULL, NULL, NULL, 'Customer', 'Retail', NULL, NULL, '67321 West Siam St.', 'Cupertino', 'CA', '23353', 'USA', NULL, '(990) 884-6345', NULL, 'www.sugarthe.us', NULL, NULL, NULL, '67321 West Siam St.', 'Cupertino', 'CA', '23353', 'USA', NULL, NULL, NULL, NULL);
INSERT INTO `sugarcli_test_accounts` (`id`, `name`, `date_entered`, `date_modified`, `modified_user_id`, `created_by`, `description`, `deleted`, `assigned_user_id`, `team_id`, `team_set_id`, `facebook`, `twitter`, `googleplus`, `account_type`, `industry`, `annual_revenue`, `phone_fax`, `billing_address_street`, `billing_address_city`, `billing_address_state`, `billing_address_postalcode`, `billing_address_country`, `rating`, `phone_office`, `phone_alternate`, `website`, `ownership`, `employees`, `ticker_symbol`, `shipping_address_street`, `shipping_address_city`, `shipping_address_state`, `shipping_address_postalcode`, `shipping_address_country`, `parent_id`, `sic_code`, `duns_num`, `campaign_id`) VALUES('1fc19aa8-0f47-df4a-26c3-57d02c22a0fb', 'MMM Mortuary Corp', '2016-09-07 15:03:20', '2016-09-07 15:03:20', '1', '1', NULL, 0, 'seed_max_id', 'West', '718eecb2-5273-8be2-968a-57d02cdee75f', NULL, NULL, NULL, 'Customer', 'Media', NULL, NULL, '67321 West Siam St.', 'San Mateo', 'CA', '54768', 'USA', NULL, '(273) 057-3364', NULL, 'www.hrsupport.co.uk', NULL, NULL, NULL, '67321 West Siam St.', 'San Mateo', 'CA', '54768', 'USA', NULL, NULL, NULL, NULL);
INSERT INTO `sugarcli_test_accounts` (`id`, `name`, `date_entered`, `date_modified`, `modified_user_id`, `created_by`, `description`, `deleted`, `assigned_user_id`, `team_id`, `team_set_id`, `facebook`, `twitter`, `googleplus`, `account_type`, `industry`, `annual_revenue`, `phone_fax`, `billing_address_street`, `billing_address_city`, `billing_address_state`, `billing_address_postalcode`, `billing_address_country`, `rating`, `phone_office`, `phone_alternate`, `website`, `ownership`, `employees`, `ticker_symbol`, `shipping_address_street`, `shipping_address_city`, `shipping_address_state`, `shipping_address_postalcode`, `shipping_address_country`, `parent_id`, `sic_code`, `duns_num`, `campaign_id`) VALUES('2961d17a-4f34-13d8-fc88-59130f04f64b', 'TEST ETL PHPUNIT', '2017-05-10 13:03:02', '2017-05-10 13:03:02', '1', '1', NULL, 1, '1', '1', '1', NULL, NULL, NULL, 'Analyst', NULL, '1234', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Transformed', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `sugarcli_test_accounts` (`id`, `name`, `date_entered`, `date_modified`, `modified_user_id`, `created_by`, `description`, `deleted`, `assigned_user_id`, `team_id`, `team_set_id`, `facebook`, `twitter`, `googleplus`, `account_type`, `industry`, `annual_revenue`, `phone_fax`, `billing_address_street`, `billing_address_city`, `billing_address_state`, `billing_address_postalcode`, `billing_address_country`, `rating`, `phone_office`, `phone_alternate`, `website`, `ownership`, `employees`, `ticker_symbol`, `shipping_address_street`, `shipping_address_city`, `shipping_address_state`, `shipping_address_postalcode`, `shipping_address_country`, `parent_id`, `sic_code`, `duns_num`, `campaign_id`) VALUES('2a2b0772-b127-a8e6-3f46-57d02cac2160', 'Southern Realty', '2016-09-07 15:03:20', '2016-09-07 15:03:20', '1', '1', NULL, 0, 'seed_chris_id', 'East', 'East', NULL, NULL, NULL, 'Customer', 'Shipping', NULL, NULL, '777 West Filmore Ln', 'Santa Monica', 'NY', '24962', 'USA', NULL, '(577) 740-3197', NULL, 'www.hrsales.org', NULL, NULL, NULL, '777 West Filmore Ln', 'Santa Monica', 'NY', '24962', 'USA', NULL, NULL, NULL, NULL);
INSERT INTO `sugarcli_test_accounts` (`id`, `name`, `date_entered`, `date_modified`, `modified_user_id`, `created_by`, `description`, `deleted`, `assigned_user_id`, `team_id`, `team_set_id`, `facebook`, `twitter`, `googleplus`, `account_type`, `industry`, `annual_revenue`, `phone_fax`, `billing_address_street`, `billing_address_city`, `billing_address_state`, `billing_address_postalcode`, `billing_address_country`, `rating`, `phone_office`, `phone_alternate`, `website`, `ownership`, `employees`, `ticker_symbol`, `shipping_address_street`, `shipping_address_city`, `shipping_address_state`, `shipping_address_postalcode`, `shipping_address_country`, `parent_id`, `sic_code`, `duns_num`, `campaign_id`) VALUES('305822a0-b1aa-d6e5-ead4-57d02c23327a', 'Max Holdings Ltd', '2016-09-07 15:03:20', '2016-09-07 15:03:20', '1', '1', NULL, 0, 'seed_will_id', 'East', 'East', NULL, NULL, NULL, 'Customer', '', NULL, NULL, '123 Anywhere Street', 'Ohio', 'NY', '66756', 'USA', NULL, '(505) 603-3950', NULL, 'www.kiddev.us', NULL, NULL, NULL, '123 Anywhere Street', 'Ohio', 'NY', '66756', 'USA', NULL, NULL, NULL, NULL);
INSERT INTO `sugarcli_test_accounts` (`id`, `name`, `date_entered`, `date_modified`, `modified_user_id`, `created_by`, `description`, `deleted`, `assigned_user_id`, `team_id`, `team_set_id`, `facebook`, `twitter`, `googleplus`, `account_type`, `industry`, `annual_revenue`, `phone_fax`, `billing_address_street`, `billing_address_city`, `billing_address_state`, `billing_address_postalcode`, `billing_address_country`, `rating`, `phone_office`, `phone_alternate`, `website`, `ownership`, `employees`, `ticker_symbol`, `shipping_address_street`, `shipping_address_city`, `shipping_address_state`, `shipping_address_postalcode`, `shipping_address_country`, `parent_id`, `sic_code`, `duns_num`, `campaign_id`) VALUES('30ec66ce-aab9-11da-82fa-57d02c87a63c', 'DD Furniture Inc', '2016-09-07 15:03:20', '2016-09-07 15:03:20', '1', '1', NULL, 0, 'seed_sarah_id', 'West', '7b59ddce-dccd-917a-5471-57d02ca20c96', NULL, NULL, NULL, 'Customer', 'Electronics', NULL, NULL, '9 IBM Path', 'San Jose', 'CA', '63670', 'USA', NULL, '(640) 633-4846', NULL, 'www.phoneqa.com', NULL, NULL, NULL, '9 IBM Path', 'San Jose', 'CA', '63670', 'USA', NULL, NULL, NULL, NULL);
-- --------------------------------------------------------

--
-- Table structure for table `sugarcli_test_contacts`
--

CREATE TABLE IF NOT EXISTS `sugarcli_test_contacts` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `team_id` char(36) DEFAULT NULL,
  `team_set_id` char(36) DEFAULT NULL,
  `salutation` varchar(255) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `facebook` varchar(100) DEFAULT NULL,
  `twitter` varchar(100) DEFAULT NULL,
  `googleplus` varchar(100) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `do_not_call` tinyint(1) DEFAULT '0',
  `phone_home` varchar(100) DEFAULT NULL,
  `phone_mobile` varchar(100) DEFAULT NULL,
  `phone_work` varchar(100) DEFAULT NULL,
  `phone_other` varchar(100) DEFAULT NULL,
  `phone_fax` varchar(100) DEFAULT NULL,
  `primary_address_street` varchar(150) DEFAULT NULL,
  `primary_address_city` varchar(100) DEFAULT NULL,
  `primary_address_state` varchar(100) DEFAULT NULL,
  `primary_address_postalcode` varchar(20) DEFAULT NULL,
  `primary_address_country` varchar(255) DEFAULT NULL,
  `alt_address_street` varchar(150) DEFAULT NULL,
  `alt_address_city` varchar(100) DEFAULT NULL,
  `alt_address_state` varchar(100) DEFAULT NULL,
  `alt_address_postalcode` varchar(20) DEFAULT NULL,
  `alt_address_country` varchar(255) DEFAULT NULL,
  `assistant` varchar(75) DEFAULT NULL,
  `assistant_phone` varchar(100) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `lead_source` varchar(255) DEFAULT NULL,
  `dnb_principal_id` varchar(30) DEFAULT NULL,
  `reports_to_id` char(36) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  `mkto_sync` tinyint(1) DEFAULT '0',
  `mkto_id` int(11) DEFAULT NULL,
  `mkto_lead_score` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sugarcli_test_contacts`
--

INSERT INTO `sugarcli_test_contacts` (`id`, `date_entered`, `date_modified`, `modified_user_id`, `created_by`, `description`, `deleted`, `assigned_user_id`, `team_id`, `team_set_id`, `salutation`, `first_name`, `last_name`, `title`, `facebook`, `twitter`, `googleplus`, `department`, `do_not_call`, `phone_home`, `phone_mobile`, `phone_work`, `phone_other`, `phone_fax`, `primary_address_street`, `primary_address_city`, `primary_address_state`, `primary_address_postalcode`, `primary_address_country`, `alt_address_street`, `alt_address_city`, `alt_address_state`, `alt_address_postalcode`, `alt_address_country`, `assistant`, `assistant_phone`, `picture`, `lead_source`, `dnb_principal_id`, `reports_to_id`, `birthdate`, `campaign_id`, `mkto_sync`, `mkto_id`, `mkto_lead_score`) VALUES('1', '2017-05-10 13:07:21', '2017-05-10 13:07:24', '1', '1', NULL, 1, NULL, '1', '1', 'Dr.', 'Jean', 'Durand', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `sugarcli_test_contacts` (`id`, `date_entered`, `date_modified`, `modified_user_id`, `created_by`, `description`, `deleted`, `assigned_user_id`, `team_id`, `team_set_id`, `salutation`, `first_name`, `last_name`, `title`, `facebook`, `twitter`, `googleplus`, `department`, `do_not_call`, `phone_home`, `phone_mobile`, `phone_work`, `phone_other`, `phone_fax`, `primary_address_street`, `primary_address_city`, `primary_address_state`, `primary_address_postalcode`, `primary_address_country`, `alt_address_street`, `alt_address_city`, `alt_address_state`, `alt_address_postalcode`, `alt_address_country`, `assistant`, `assistant_phone`, `picture`, `lead_source`, `dnb_principal_id`, `reports_to_id`, `birthdate`, `campaign_id`, `mkto_sync`, `mkto_id`, `mkto_lead_score`) VALUES('100001a8-396f-cd2e-0a91-58dbce595b94', '2016-09-07 15:03:00', '2017-03-29 15:09:00', '1', '1', NULL, 0, 'seed_chris_id', 'East', 'East', NULL, 'Claudia', 'Tolbert dup', 'Director Operations', NULL, NULL, NULL, NULL, 0, '(342) 198-7048', '(796) 810-1390', '(143) 104-7968', NULL, NULL, '345 Sugar Blvd.', 'San Mateo', 'NY', '92081', 'USA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Self Generated', NULL, NULL, NULL, '', 0, 0, 0);
INSERT INTO `sugarcli_test_contacts` (`id`, `date_entered`, `date_modified`, `modified_user_id`, `created_by`, `description`, `deleted`, `assigned_user_id`, `team_id`, `team_set_id`, `salutation`, `first_name`, `last_name`, `title`, `facebook`, `twitter`, `googleplus`, `department`, `do_not_call`, `phone_home`, `phone_mobile`, `phone_work`, `phone_other`, `phone_fax`, `primary_address_street`, `primary_address_city`, `primary_address_state`, `primary_address_postalcode`, `primary_address_country`, `alt_address_street`, `alt_address_city`, `alt_address_state`, `alt_address_postalcode`, `alt_address_country`, `assistant`, `assistant_phone`, `picture`, `lead_source`, `dnb_principal_id`, `reports_to_id`, `birthdate`, `campaign_id`, `mkto_sync`, `mkto_id`, `mkto_lead_score`) VALUES('1010e9a6-3906-8261-05c2-58dbcca050a7', '2016-09-07 15:03:00', '2017-03-29 15:02:00', '1', '1', NULL, 0, 'seed_max_id', 'West', 'West', NULL, 'Neomi', 'Fleeman dup', 'VP Operations', NULL, NULL, NULL, NULL, 0, '(503) 065-7766', '(781) 753-9613', '(845) 174-1734', NULL, NULL, '111 Silicon Valley Road', 'Salt Lake City', 'CA', '83343', 'USA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Trade Show', NULL, NULL, NULL, '', 0, 0, 0);
INSERT INTO `sugarcli_test_contacts` (`id`, `date_entered`, `date_modified`, `modified_user_id`, `created_by`, `description`, `deleted`, `assigned_user_id`, `team_id`, `team_set_id`, `salutation`, `first_name`, `last_name`, `title`, `facebook`, `twitter`, `googleplus`, `department`, `do_not_call`, `phone_home`, `phone_mobile`, `phone_work`, `phone_other`, `phone_fax`, `primary_address_street`, `primary_address_city`, `primary_address_state`, `primary_address_postalcode`, `primary_address_country`, `alt_address_street`, `alt_address_city`, `alt_address_state`, `alt_address_postalcode`, `alt_address_country`, `assistant`, `assistant_phone`, `picture`, `lead_source`, `dnb_principal_id`, `reports_to_id`, `birthdate`, `campaign_id`, `mkto_sync`, `mkto_id`, `mkto_lead_score`) VALUES('102a0fb6-2552-4fcd-cc13-58dbced1d7de', '2016-09-07 15:03:00', '2017-03-29 15:09:00', '1', '1', NULL, 0, 'seed_max_id', 'West', 'West', NULL, 'Susann', 'Delima dup', 'Director Sales', NULL, NULL, NULL, NULL, 0, '(477) 366-1876', '(401) 468-8333', '(279) 298-5511', NULL, NULL, '48920 San Carlos Ave', 'Santa Fe', 'CA', '49712', 'USA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Existing Customer', NULL, NULL, NULL, '', 0, 0, 0);
INSERT INTO `sugarcli_test_contacts` (`id`, `date_entered`, `date_modified`, `modified_user_id`, `created_by`, `description`, `deleted`, `assigned_user_id`, `team_id`, `team_set_id`, `salutation`, `first_name`, `last_name`, `title`, `facebook`, `twitter`, `googleplus`, `department`, `do_not_call`, `phone_home`, `phone_mobile`, `phone_work`, `phone_other`, `phone_fax`, `primary_address_street`, `primary_address_city`, `primary_address_state`, `primary_address_postalcode`, `primary_address_country`, `alt_address_street`, `alt_address_city`, `alt_address_state`, `alt_address_postalcode`, `alt_address_country`, `assistant`, `assistant_phone`, `picture`, `lead_source`, `dnb_principal_id`, `reports_to_id`, `birthdate`, `campaign_id`, `mkto_sync`, `mkto_id`, `mkto_lead_score`) VALUES('102f8b9d-834b-4290-a313-58dbcd3e0435', '2016-09-07 15:03:00', '2017-03-29 15:02:00', '1', '1', NULL, 0, 'seed_sally_id', 'West', 'West', NULL, 'Omega', 'Redden dup dup', 'Director Operations', NULL, NULL, NULL, NULL, 0, '(503) 587-5627', '(575) 576-7925', '(286) 856-3411', NULL, NULL, '777 West Filmore Ln', 'Persistance', 'CA', '80727', 'USA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Employee', NULL, NULL, NULL, '', 0, 0, 0);
INSERT INTO `sugarcli_test_contacts` (`id`, `date_entered`, `date_modified`, `modified_user_id`, `created_by`, `description`, `deleted`, `assigned_user_id`, `team_id`, `team_set_id`, `salutation`, `first_name`, `last_name`, `title`, `facebook`, `twitter`, `googleplus`, `department`, `do_not_call`, `phone_home`, `phone_mobile`, `phone_work`, `phone_other`, `phone_fax`, `primary_address_street`, `primary_address_city`, `primary_address_state`, `primary_address_postalcode`, `primary_address_country`, `alt_address_street`, `alt_address_city`, `alt_address_state`, `alt_address_postalcode`, `alt_address_country`, `assistant`, `assistant_phone`, `picture`, `lead_source`, `dnb_principal_id`, `reports_to_id`, `birthdate`, `campaign_id`, `mkto_sync`, `mkto_id`, `mkto_lead_score`) VALUES('1038b1ed-d0a4-783c-0ecb-58dbcee97066', '2016-09-07 15:03:00', '2017-03-29 15:10:00', '1', '1', NULL, 0, 'seed_will_id', 'East', 'East', NULL, 'Millie', 'Banda dup', 'Director Sales', NULL, NULL, NULL, NULL, 0, '(280) 431-3838', '(502) 798-3141', '(097) 716-2227', NULL, NULL, '123 Anywhere Street', 'St. Petersburg', 'NY', '26918', 'USA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Public Relations', NULL, NULL, NULL, '', 0, 0, 0);
INSERT INTO `sugarcli_test_contacts` (`id`, `date_entered`, `date_modified`, `modified_user_id`, `created_by`, `description`, `deleted`, `assigned_user_id`, `team_id`, `team_set_id`, `salutation`, `first_name`, `last_name`, `title`, `facebook`, `twitter`, `googleplus`, `department`, `do_not_call`, `phone_home`, `phone_mobile`, `phone_work`, `phone_other`, `phone_fax`, `primary_address_street`, `primary_address_city`, `primary_address_state`, `primary_address_postalcode`, `primary_address_country`, `alt_address_street`, `alt_address_city`, `alt_address_state`, `alt_address_postalcode`, `alt_address_country`, `assistant`, `assistant_phone`, `picture`, `lead_source`, `dnb_principal_id`, `reports_to_id`, `birthdate`, `campaign_id`, `mkto_sync`, `mkto_id`, `mkto_lead_score`) VALUES('103b67a1-a40e-bfe4-ff2c-58dbce3792d7', '2016-09-07 15:03:00', '2017-03-29 15:09:00', '1', '1', NULL, 0, 'seed_max_id', 'West', '7b59ddce-dccd-917a-5471-57d02ca20c96', NULL, 'Lyle', 'Muhammad dup dup', 'VP Operations', NULL, NULL, NULL, NULL, 0, '(986) 440-3554', '(659) 103-5350', '(573) 944-8737', NULL, NULL, '48920 San Carlos Ave', 'Sunnyvale', 'CA', '88890', 'USA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Mail', NULL, NULL, NULL, '', 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sugarcli_test_accounts`
--
ALTER TABLE `sugarcli_test_accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_accounts_date_modfied` (`date_modified`),
  ADD KEY `idx_accounts_id_del` (`id`,`deleted`),
  ADD KEY `idx_accounts_date_entered` (`date_entered`),
  ADD KEY `idx_accounts_tmst_id` (`team_set_id`),
  ADD KEY `idx_accnt_name_del` (`name`,`deleted`),
  ADD KEY `idx_accnt_assigned_del` (`deleted`,`assigned_user_id`),
  ADD KEY `idx_accnt_parent_id` (`parent_id`),
  ADD KEY `idx_account_billing_address_city` (`billing_address_city`),
  ADD KEY `idx_account_billing_address_country` (`billing_address_country`);

--
-- Indexes for table `sugarcli_test_contacts`
--
ALTER TABLE `sugarcli_test_contacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_contacts_date_modfied` (`date_modified`),
  ADD KEY `idx_contacts_id_del` (`id`,`deleted`),
  ADD KEY `idx_contacts_date_entered` (`date_entered`),
  ADD KEY `idx_contacts_tmst_id` (`team_set_id`),
  ADD KEY `idx_cont_last_first` (`last_name`,`first_name`,`deleted`),
  ADD KEY `idx_contacts_del_last` (`deleted`,`last_name`),
  ADD KEY `idx_cont_del_reports` (`deleted`,`reports_to_id`,`last_name`),
  ADD KEY `idx_reports_to_id` (`reports_to_id`),
  ADD KEY `idx_del_id_user` (`deleted`,`id`,`assigned_user_id`),
  ADD KEY `idx_cont_assigned` (`assigned_user_id`),
  ADD KEY `idx_contact_title` (`title`),
  ADD KEY `idx_contact_mkto_id` (`mkto_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
