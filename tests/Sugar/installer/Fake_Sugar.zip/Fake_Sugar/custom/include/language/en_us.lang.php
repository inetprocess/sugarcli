<?php

$GLOBALS['test'] = 'foo';
